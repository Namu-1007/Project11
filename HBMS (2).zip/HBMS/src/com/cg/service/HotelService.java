package com.cg.service;

import com.cg.bean.Hotels;
import com.cg.exception.HotelException;

public interface HotelService
{
	public int addHotels(Hotels htl) throws HotelException;
	public int updateHtl(int htlId) throws HotelException;
	public boolean validateAdmName(String cName) throws HotelException;
	public boolean validateAdmPass(String adPass) throws HotelException;
}

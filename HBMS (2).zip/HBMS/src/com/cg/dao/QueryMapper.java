package com.cg.dao;

public interface QueryMapper 
{
	String INSERT_HOTEL="INSERT INTO HOTEL VALUES(?,?,?,?,?,?,?,?,?,?,?)";
	String DELETE_HOTEL="DELETE FROM HOTEL WHERE hotelid=?";
	String SEQUENCE="SELECT htl_id_seq.NEXTVAL FROM DUAL";
}

package com.cg.dao;

import java.sql.*;

import com.cg.bean.*;
import com.cg.exception.*;
import com.cg.util.DBUtil;
import com.cg.dao.*;


public class HotelDaoImpl implements HotelDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public int addHotels(Hotels htl) throws HotelException
	{
		int dataAdded=0;	
		try
		{
			con =DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.INSERT_HOTEL);

			pst.setInt(1,generateHotelId());
			pst.setString(2,htl.getCity());
			pst.setString(3,htl.getHotelName());
			pst.setString(4,htl.getAddress());
			pst.setString(5,htl.getDescription());
			pst.setFloat(6,htl.getAvgRate());
			pst.setString(7,htl.getPh1());
			pst.setString(8,htl.getPh2());
			pst.setString(9,htl.getRating());
			pst.setString(10,htl.getEmail());
			pst.setString(11,htl.getFax());

			dataAdded=pst.executeUpdate();
		}
		catch(Exception e)
		{		
			throw new HotelException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
				st.close();
			}
			catch(SQLException e)
			{
				throw new HotelException(e.getMessage());
			}
		}
		return dataAdded;	
	}

	@Override
	public int updateHtl(int htlId) throws HotelException 
	{
		
		return 0;
	}

	
	private int generateHotelId() throws HotelException 
	{
		int htlid=0;
		
		try
		{
			con =DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(QueryMapper.SEQUENCE);
			rs.next();
			htlid=rs.getInt(1);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		throw new HotelException(e.getMessage());
	}
	finally
	{
		try
		{
			rs.close();
			st.close();
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new HotelException(e.getMessage());
		}
	}
	return htlid;		
	}

	@Override
	public int deleteHotels(int htlId) throws HotelException {
		// TODO Auto-generated method stub
		return 0;
	}
	
}

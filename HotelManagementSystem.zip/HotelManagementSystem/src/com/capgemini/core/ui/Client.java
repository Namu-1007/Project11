package com.capgemini.core.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.dto.BookingDetails;
import com.capgemini.core.dto.Hotel;
import com.capgemini.core.dto.RoomDetails;
import com.capgemini.core.dto.User;
import com.capgemini.core.exception.HMSException;
import com.capgemini.core.service.HMSAdminServiceImpl;
import com.capgemini.core.service.HMSUserServiceImpl;
import com.capgemini.core.service.IHMSAdminService;
import com.capgemini.core.service.IHMSUserService;

public class Client {
	IHMSAdminService adminService;
	IHMSUserService userService;
	private String userId;
	private Scanner scanner = new Scanner(System.in);

	public Client() {
		adminService = new HMSAdminServiceImpl();
		userService = new HMSUserServiceImpl();
	}

	private void Mainmenu() {
		System.out.println("1) Admin");
		System.out.println("2) User");
		System.out.println("3) Exit");
		System.out.println("Please Enter Your Choice");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			AdminLogin();
			break;
		case 2:
			UserChoice();
			break;
		case 3:
			System.out.println("Good Bye!");
			System.exit(0);
			break;
		default:
			System.out.println("Enter correct choice");
			Mainmenu();
		}
	}

	private void AdminLogin() {
		System.out.print("Enter Admin name: ");
		String user = scanner.next();
		System.out.print("Enter Password: ");
		String password = scanner.next();
		if (user.equalsIgnoreCase("admin") && password.equalsIgnoreCase("password")) {
			System.out.println("Hello Admin You Are Successfully Logged in\n");
			AdminChoice();
		} else {
			System.out.println("Invalid credentials...Please Try Again..!!\n");
			AdminLogin();
		}
	}

	private void UserChoice() {
		System.out.println("1) Login");
		System.out.println("2) Register");
		System.out.println("3) Exit");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			if (userLogin()) {
				userMenu();
			}
			break;
		case 2:
			if (userRegister()) {
				if (userLogin()) {
					userMenu();
				}
			}
			break;
		case 3:
			System.out.println("Good Bye!");
			System.exit(0);
			break;
		default:
			System.out.println("Enter correct choice");
			UserChoice();
		}
	}

	private void userMenu() {
		System.out.println("1) Search for hotel");
		System.out.println("2) Book A Hotel");
		System.out.println("3) View Booking status");
		System.out.println("4) Exit");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			searchHotel();
			userMenu();
			break;
		case 2:
			bookHotel();
			userMenu();
			break;
		case 3:
			bookingSatus();
			userMenu();
			break;
		case 4:
			System.out.println("Good Bye!");
			System.exit(0);
			break;
		default:
			System.out.println("Enter correct choice");
			userMenu();
		}
	}

	private void searchHotel() {
		System.out.println("Enter the City where you want to book hotel :");
		String city= scanner.next();
		/*System.out.print("Enter hotel ID: ");
		String hotelId = scanner.next();
		try {
			Hotel hotel = userService.searchHotel(hotelId);
			System.out.println("**********************HOTEL DETAILS**********************");
			System.out.println("Hotel Name :" +hotel.getName()  + "\n" + "City : " + hotel.getCity() + "\n"  + "Address : " + hotel.getAddress() +"\n"
					+ "Description : " + hotel.getDescription() + "\n" + "Rate Per Night : " +hotel.getAvgPerNight() + "\n" + "Phone Number : " + hotel.getPhoneNo1() + ", "
					+ hotel.getPhoneNo2() + "\n" + "Ratings : " + hotel.getRating() + "\n" + "Email Id : " + hotel.getEmail() + "\n" + "Fax : " +hotel.getFax());
		} catch (HMSException e) {
			System.out.println("Something went wrong. Reason " + e.getMessage());
		}*/
		try{
			List<Hotel> hotelList=new ArrayList<Hotel>();
			hotelList=userService.search(city);
			//System.out.println("");
			//Iterator<Hotel> iterator=hotelList.iterator();
			System.out.println("\n************* LIST OF HOTELS **************");
			for(Hotel hotel:hotelList){
				System.out.println(hotel.toString());
			}	
			userMenu();
		}catch(HMSException e){
			System.out.println("Sorry! We do not serve this location yet.");
		}
	}

	private void bookHotel() {
		System.out.println("Enter Hotel Name :");
		scanner.nextLine();
		String hotelname = scanner.nextLine();
		try {
			List<RoomDetails> roomList = new ArrayList<>();
			roomList = userService.displayRooms(hotelname);
			
			for (RoomDetails roomDetails : roomList) {
				System.out.println(roomDetails.toString());
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
		System.out.print("Enter Room Id: ");
		String roomId = scanner.next();
		//System.out.print("Enter User Id: ");
		System.out.print("Enter book date from: ");
		String bookFrom = scanner.next();
		System.out.print("Enter book date to: ");
		String bookTo = scanner.next();
		System.out.print("Enter No of adults: ");
		int adults = scanner.nextInt();
		System.out.print("Enter No of Childrens: ");
		int childrens = scanner.nextInt();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate fromDate = LocalDate.parse(bookFrom, formatter);
		LocalDate toDate = LocalDate.parse(bookTo, formatter);

		
		try {
			double amount=userService.generateBill(roomId, fromDate, toDate);
			System.out.println("Your Total bill is : "+amount);
			System.out.println("To confirm press Y else N");
			if("Y".equalsIgnoreCase(scanner.next())){
			BookingDetails bookingdetails = new BookingDetails(roomId, userId, fromDate, toDate, adults, childrens,amount);
			String bookID = userService.bookHotel(bookingdetails);
			if(!bookID.equals("false")){
			System.out.println("Booking successfull. Booking ID: " + bookID);
			}
			else{
				System.out.println("Room is not available for this date.");
				System.exit(0);
			}}
		} catch (HMSException e) {
			System.out.println("Something went wrong. Reason" + e.getMessage());
		}
	}

	private void bookingSatus() {
		System.out.println("Enter User ID:");
		String user=scanner.next();
		if(userService.bookingStatus(user)){
			System.out.println("Your Booking is confirmed");
		}
		else{
			System.out.println("There is no booking with this Id!");
		}
	}

	private boolean userLogin() {
		boolean status = false;
		System.out.println("\nEnter details to Login\n");
		System.out.print("Enetr User ID:");
		userId = scanner.next();
		System.out.println("Enter Password: ");
		String password = scanner.next();
		User user = new User(userId, password);
		try {
			status = userService.login(user);
			if (status)
				System.out.println("Logged in successfully\n");
			else
				System.out.println("Invalid Credentials.....Please Try Again..!!\n");
		} catch (HMSException e) {
			System.out.println("Something went wrong. Reason " + e.getMessage());
		}
		return status;
	}

	private boolean userRegister() {
		System.out.println("\nUser Registration\n");
		System.out.println("Enter User Name: ");
		String userName = scanner.next();
		System.out.println("Enter Password: ");
		String password = scanner.next();
		String role = "User";
		System.out.println("Enter mobile Number: ");
		String mobile = scanner.next();
		System.out.println("Enter Phone: ");
		String phone = scanner.next();
		System.out.println("Enter email: ");
		String email = scanner.next();
		System.out.println("Enter Address: ");
		String address = scanner.next();
		User user = new User(userName, password, email, mobile, phone, role, address);
		try {
			int id = userService.register(user);
			System.out.println("Registered successfully. Your User ID : " + id);
			return true;
		} catch (HMSException e) {
			System.out.println("Something went wrong. Reason " + e.getMessage());
		}
		return false;
	}

	private void AdminChoice() {
		System.out.println("1) Perform Hotel Management");
		System.out.println("2) Perform Room Management");
		System.out.println("3) Generate Reports");
		System.out.println("4) Exit");
		System.out.println("Please Enter Your Choice");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			hotelManage();
			AdminChoice();
			break;
		case 2:
			roomManage();
			AdminChoice();
			break;
		case 3:
			generateReports();
			AdminChoice();
			break;
		case 4:
			System.out.println("Good Bye!");
			System.exit(0);
			break;
		default:
			System.out.println("Enter correct choice");
			AdminChoice();
		}
	}

	private void hotelManage() {
		System.out.println("1) Add hotel");
		System.out.println("2) Delete Hotel");
		System.out.println("3) Modify Hotel");
		System.out.println("4) Exit");
		System.out.println("Please Enter Your Choice");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			addHotel();
			break;
		case 2:
			deleteHotel();
			break;
		case 3:
			modifyHotel();
			break;
		case 4:
			System.out.println("Good Bye!");
			System.exit(0);
			break;
		default:
			System.out.println("Enter correct choice");
			hotelManage();
		}
	}

	private void roomManage() {
		System.out.println("1) Add Room");
		System.out.println("2) Delete Room");
		System.out.println("3) Modify Room");
		System.out.println("4) Exit");
		System.out.println("Please Enter Your Choice");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			addRoom();
			break;
		case 2:
			deleteRoom();
			break;
		case 3:
			modifyRoom();
			break;
		case 4:
			System.out.println("Good Bye!");
			System.exit(0);
			break;
		default:
			System.out.println("Enter correct choice");
			roomManage();
		}
	}

	private void generateReports() {
		System.out.println("1) List of Hotels");
		System.out.println("2) Bookings of specific hotel");
		System.out.println("3) Guest list of specific hotel");
		System.out.println("4) Bookings for specific date");
		System.out.println("5) Exit");
		System.out.println("Please Enter Your Choice");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			listOfHotel();
			AdminChoice();
			break;
		case 2:
			specificHotelBookings();
			AdminChoice();
			break;
		case 3:
			guestOfSpecificHotel();
			AdminChoice();
			break;
		case 4:
			bookingOfSpecificDate();
			AdminChoice();
			break;
		case 5:
			System.out.println("Good Bye!");
			System.exit(0);
			break;
		default:
			System.out.println("Enter correct choice");
			generateReports();
		}
	}

	private void listOfHotel() {
		try {
			ArrayList<Hotel> hotels = (ArrayList<Hotel>) adminService.listOfHotel();
			
			for (Hotel index : hotels) {
				System.out.println("======================" + "\n"
						           + "Hotel ID      : " + index.getId() + "\n" 
								   + "======================" + "\n"
							       + "Hotel City  : " + index.getCity() + "\n" 
							       + "Hotel Name  : " + index.getName() + "\n"
							       + "Address     : " + index.getAddress() + "\n" 
							       + "Description : " + index.getDescription() + "\n" 
							       + "Rate        : " + index.getAvgPerNight() + "\n"
							       + "Phone No 1  : " + index.getPhoneNo1() + "\n" 
							       + "Phone No 2  : " + index.getPhoneNo2() + "\n" 
							       + "Rating      : " + index.getRating() + "\n"
							       + "Email       : " + index.getEmail() + "\n" 
							       + "Fax         : " + index.getFax());
				System.out.println();
			}
		} catch (HMSException e) {
			System.out.println("Something went Wrong.Reason " + e.getMessage());
		}
	}

	private void specificHotelBookings() {
		System.out.print("Enter Hotel ID: ");
		String hotelID = scanner.next();
		try {
			ArrayList<BookingDetails> bookings = (ArrayList<BookingDetails>) adminService
					.specificHotelBookings(hotelID);
			
			for (BookingDetails book : bookings) {
				System.out.println("=================================" + "\n"
								   + "Specific Hotel Booking Details" + "\n"
								   + "===============================" + "\n"
								   + "Booking ID  : " + book.getId() + "\n" 
								   + "Room ID     : " + book.getRoomId() + "\n" 
								   + "User ID     : " + book.getUserId() + "\n"
								   + "Booked From : " +book.getBookFrom() + "\n" 
								   + "Booked To   : " + book.getBooTo() + "\n" 
								   + "Adults      : " +book.getNoOfAdults() + "\n"
								   + "Childrens   : " + book.getNoOfChildren() + "\n"
								   + "Amount      : " + book.getAmount());
				System.out.println();
			}
		} catch (HMSException e) {
			System.out.println("Something went wrong. Reason " + e.getMessage());
		}
	}

	private void guestOfSpecificHotel() {
		System.out.print("Enter Hotel ID: ");
		String hotelId = scanner.next();
		try {
			ArrayList<User> users = (ArrayList<User>) adminService.guestOfSpecificHotel(hotelId);
			for (User userInfo : users) {
				System.out.println("=================================" + "\n"
						   		   + "Guest List Of Specific Hotel" + "\n"
						           + "===============================" + "\n"
						           + "User ID   : " +userInfo.getId() + "\n" 
						           + "Password  : " +userInfo.getPassword() + "\n" 
						           + "Role      : " +userInfo.getRole() + "\n"
						           + "User Name : " +userInfo.getName() + "\n"
						           + "Mobile No : " +userInfo.getMobileNumber() + "\n" 
						           + "Phone No  : " +userInfo.getPhoneNumber() + "\n" 
						           + "Address   : " +userInfo.getAddress()+ "\n" 
						           + "Email     : " + userInfo.getEmail());
				System.out.println();
			}
		} catch (HMSException e) {
			System.out.println("Something went wrong. Reason " + e.getMessage());
		}
	}

	private void bookingOfSpecificDate() {
		System.out.print("Enter a date: ");
		String dateStr = scanner.next();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate bookDate = LocalDate.parse(dateStr, formatter);
		try {
			ArrayList<BookingDetails> bookings = (ArrayList<BookingDetails>) adminService
					.bookingOfSpecificDate(bookDate);
			for (BookingDetails book : bookings) {
				System.out.println("=================================" + "\n"
							       + "Booking For Specific Date" + "\n"
				                   + "===============================" + "\n"
				                   + "Booking ID     : " + book.getId() + "\n" 
				                   + "Room ID        : " + book.getRoomId() + "\n" 
				                   + "User ID        : " + book.getUserId() + "\n"
				                   + "Check In Date  : " + book.getBookFrom() + "\n" 
				                   + "Check Out Date : " + book.getBooTo() + "\n" 
				                   + "No Of Adults   : " + book.getNoOfAdults() + "\n"
				                   + "No Of Children : " + book.getNoOfChildren() + "\n" 
				                   + "Total Amount   : " + book.getAmount());
				System.out.println();
			}
		} catch (HMSException e) {
			System.out.println("Something went wrong. Reason " + e.getMessage());
		}
	}

	private void addRoom() {
		System.out.println("=======ADD ROOM=======");

		System.out.print("Enter Hotel ID: ");
		String hotelID = scanner.next();
		System.out.print("Enter Room ID: ");
		String roomID = scanner.next();
		System.out.print("Enter Room Number: ");
		String roomNumber = scanner.next();
		System.out.print("Enter Room Type: ");
		String roomType = scanner.next();
		System.out.print("Enter Per Night Rate: ");
		double roomRate = scanner.nextDouble();
		System.out.print("Enter Availability: ");
		String roomAvailable = scanner.next();

		RoomDetails room = new RoomDetails(hotelID, roomID, roomNumber, roomType, roomRate, roomAvailable);
		try {
			String id = adminService.addRoom(room);
			System.out.println("Room " + id + " added to Hotel " + room.getHotelId() + " successfully");
			System.out.println();
		} catch (Exception e) {
			System.out.println("Something went wrong. Reason" + e.getMessage());
		}
	}

	private void deleteRoom() {
		System.out.println("======DELETE ROOM========");
		System.out.println("Enter Hotel ID: ");
		String hotelID=scanner.next();
		System.out.print("Enter Room ID: ");
		String roomID = scanner.next();
		try {
			String id = adminService.deleteRoom(roomID,hotelID);
			System.out.println("Room " + id + " deleted successfully");
			System.out.println();
		} catch (Exception e) {
			System.out.println("Something went wrong. Reason " + e.getMessage());
		}
	}

	private void modifyRoom() {
		System.out.println("=======MODIFY ROOM=======");
		
		System.out.print("Enter Room ID: ");
		String roomID = scanner.next();
		System.out.print("Enter Room Number: ");
		String roomNumber = scanner.next();
		System.out.print("Enter Room Type: ");
		scanner.nextLine();
		String roomType = scanner.nextLine();
		System.out.print("Enter Per Night Rate: ");
		double roomRate = scanner.nextDouble();
		System.out.print("Enter Availability: ");
		scanner.nextLine();
		String roomAvailable = scanner.nextLine();

		RoomDetails room = new RoomDetails(roomID, roomNumber, roomType, roomRate, roomAvailable);
		try {
			String id = adminService.modifyRoom(room);
			System.out.println("Room " + id + " modified successfully");
			//System.out.println();
		} catch (Exception e) {
			System.out.println("Room Updation Failed. Reason " + e.getMessage());
		}
	}

	private void addHotel() {
		System.out.println("========ADD HOTEl=======");
		System.out.print("Enter Hotel ID: ");
		String hotelId = scanner.next();
		System.out.print("Enter Hotel city: ");
		String hotelCity = scanner.next();
		System.out.print("Enter Hotel Name: ");
		String hotelName = scanner.next();
		System.out.print("Enter Hotel Address: ");
		String hotelAddress = scanner.next();
		System.out.print("Enter Hotel Description: ");
		String hotelDescription = scanner.next();
		System.out.print("Enter Hotel Average rate per night: ");
		Double hotelRate = scanner.nextDouble();
		System.out.print("Enter Phone no 1: ");
		String hotelPhoneNo1 = scanner.next();
		System.out.print("Enter Hotel Phone no 2: ");
		String hotelPhoneNo2 = scanner.next();
		System.out.print("Enter Hotel Rating: ");
		String hotelRating = scanner.next();
		System.out.print("Enter Hotel Email: ");
		String hotelEmail = scanner.next();
		System.out.print("Enter Hotel Fax: ");
		String hotelFax = scanner.next();

		Hotel hotel = new Hotel(hotelId, hotelCity, hotelName, hotelAddress, hotelDescription, hotelRate, hotelPhoneNo1,
				hotelPhoneNo2, hotelRating, hotelEmail, hotelFax);
		try {
			String id = adminService.addHotel(hotel);
			System.out.println(id + " Hotel added successfully.");
			System.out.println();
		} catch (Exception e) {
			System.out.println("Something went Wrong. Reason" + e.getMessage());
		}
	}

	private void modifyHotel() {
		System.out.println("===========MODIFY HOTEL=========");
		System.out.print("Enter Hotel ID: ");
		scanner.nextLine();
		String hotelId = scanner.nextLine();
		System.out.print("Enter Hotel city: ");
		String hotelCity = scanner.nextLine();
		System.out.print("Enter Hotel Name: ");
		String hotelName = scanner.nextLine();
		System.out.print("Enter Hotel Address: ");
		String hotelAddress = scanner.nextLine();
		System.out.print("Enter Hotel Description: ");
		String hotelDescription = scanner.nextLine();
		System.out.print("Enter Hotel Average rate per night: ");
		Double hotelRate = scanner.nextDouble();
		System.out.print("Enter Phone no 1: ");
		scanner.nextLine();
		String hotelPhoneNo1 = scanner.nextLine();
		System.out.print("Enter Hotel Phone no 2: ");
		String hotelPhoneNo2 = scanner.nextLine();
		System.out.print("Enter Hotel Rating: ");
		String hotelRating = scanner.nextLine();
		System.out.print("Enter Hotel Email: ");
		String hotelEmail = scanner.nextLine();
		System.out.print("Enter Hotel Fax: ");
		String hotelFax = scanner.nextLine();

		Hotel hotel = new Hotel(hotelId, hotelCity, hotelName, hotelAddress, hotelDescription, hotelRate, hotelPhoneNo1,
				hotelPhoneNo2, hotelRating, hotelEmail, hotelFax);
		try {
			String id = adminService.modifyHotel(hotel);
			System.out.println("Hotel " + id + " details updated successfully");
			System.out.println();
		} catch (Exception e) {
			System.out.println("Updation Failed. Reason " + e.getMessage());
		}
	}

	private void deleteHotel() {
		System.out.println("==========DELETE HOTEL=========");
		System.out.print("Enter Hotel ID: ");
		String hotelId = scanner.next();
		try {
			String id = adminService.deleteHotel(hotelId);
			System.out.println("Hotel " + id + " deleted successfully.");
			System.out.println();
		} catch (Exception e) {
			System.out.println("Something went wrong. Reason " + e.getMessage());
		}
	}

	public static void main(String[] args) {

		Client client = new Client();
		while (true) {
			client.Mainmenu();
		}
	}
}

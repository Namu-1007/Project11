package com.cg.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotels;
import com.cg.bean.RoomDetails;
import com.cg.bean.User;
import com.cg.exception.HotelException;
import com.cg.service.HotelService;
import com.cg.service.HotelServiceImpl;
import com.cg.service.UserService;
import com.cg.service.UserServiceImpl;


public class HotelClient 
{
	static Scanner sc=null;
	static HotelService htlSer=null;
	static UserService uSer=null;
	public static void main(String[] args) 
	{
		htlSer=new HotelServiceImpl();
		uSer=new UserServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("Login As\n1.Admin\n2.User");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1: 
				System.out.println("Enter your login credentials");
				System.out.println("Enter your name");
				String name=sc.next();
				System.out.println("Enter your password");
				String pass=sc.next();
				try 
				{
					if(htlSer.validateAdmName(name))
					{
						if(htlSer.validateAdmPass(pass))
						{
							System.out.println("You have logged in successfully As Admin.Select your preferrred operation");
							System.out.println("1.Hotel Management\n"
									+ "2.Room Management\n3.View Reports");
							int c=sc.nextInt();
							switch(c)
							{
							case 1:System.out.println("1.Add Hotel\n2.Update Hotel\n3.Delete Hotel");
							System.out.println("Select your Choice ");
							int hmchoice=sc.nextInt();
							switch(hmchoice)
							{
							case 1:addHotel();
							break;
							case 2:updateHotel();
							break;
							case 3:deleteHotel();
							break;
							default: System.exit(0);
							}
							break;
							case 2:System.out.println("1.Add Rooms\n2.Update Rooms\n3.Delete Rooms");
							System.out.println("Select your Choice ");
							int roomchoice=sc.nextInt();
							switch(roomchoice)
							{
							case 1:addRoom();
							break;
							case 2:updateRoom();
							break;
							case 3:deleteRoom();
							break;
							default: System.exit(0);
							}
							break;
							case 3:System.out.println("1.View List Of Hotels"
									+ "\n2.View Bookings Of Specific hotel"
									+ "\n3.View Guest List of Specific Hotel"
									+ "\n4.View Bookings for Specified Date");
							System.out.println("Select your Choice ");
							int rprtchoice=sc.nextInt();
							switch(rprtchoice)
							{
							case 1:viewAllHotels();
							break;
							case 2:viewBookingHotel();
							break;
							case 3:viewGuestHotel();
							break;
							case 4:viewBookingDate();
							break;
							default: System.exit(0);
							}
							break;
						
							default:
								System.exit(0);
							}
						}
					}
				} 
				catch (HotelException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			case 2:System.out.println("User ");
			System.out.println("1.Login\n2.Register\n3.Search Hotel\n4.Book Hotel \n5.View Booking Status");
			System.out.println("Enter your Choice");
			int usrchoice=sc.nextInt();
			switch(usrchoice)
			{
			case 1:userLogin();
				break;
			case 2:userRegister();
			break;
			case 3:searchHotel();
				break;
			case 4:
				break;
			case 5:
				break;
			default:System.out.println("Incorrect Choice!!Enter correct choice");
				System.exit(0);
			}
			}
		}
	}
	//**************************Main Ends Here***************************//
	public static void addHotel()
	{
		System.out.println("Enter Hotel City");
		String city=sc.next();
		System.out.println("Enter Hotel Name");
		String hname=sc.next();
		System.out.println("Enter Hotel Address");
		String add=sc.next();
		System.out.println("Enter Hotel Description");
		String des=sc.next();
		System.out.println("Enter Average Rate Per Night");
		float rate=sc.nextFloat();
		System.out.println("Enter first Phone Number");
		String fphn=sc.next();
		System.out.println("Enter second Phone Number");
		String sphn=sc.next();
		System.out.println("Enter Hotel Rating");
		String rating=sc.next();
		System.out.println("Enter EmailId");
		String em=sc.next();
		System.out.println("Enter Fax Number");
		String fax=sc.next();

		try
		{
			Hotels htls=new Hotels(htlSer.generateHotelId(),
					city,hname,add,des,rate,fphn,sphn,rating,em,fax);
			int inserted=htlSer.addHotels(htls);
			if(inserted==1)
			{
				System.out.println("Hotel details are successfully inserted");
			}
			else
			{
				System.out.println("May be Some Exception");
			}
		} 
		catch (HotelException e) 
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}
	//*********************************************************************//
	public static void updateHotel()
	{
		System.out.println("Enter hotel id: ");
		String hid=sc.next();
		System.out.println("Enter Hotel City");
		String city=sc.next();
		System.out.println("Enter Hotel Name");
		String hname=sc.next();
		System.out.println("Enter Hotel Address");
		String add=sc.next();
		System.out.println("Enter Hotel Description");
		String des=sc.next();
		System.out.println("Enter Average Rate Per Night");
		float rate=sc.nextFloat();
		System.out.println("Enter first Phone Number");
		String phn1=sc.next();
		System.out.println("Enter second Phone Number");
		String phn2=sc.next();
		System.out.println("Enter Hotel Rating");
		String rating=sc.next();
		System.out.println("Enter EmailId");
		String em=sc.next();
		System.out.println("Enter Fax Number");
		String fax=sc.next();

		Hotels hotels=new Hotels(hid,city,hname,add,des,rate,phn1,phn2,rating,em,fax);
		try 
		{
			String upd=htlSer.updateHtl(hotels);

			System.out.println("Hotel " +upd+" updated successfully!");
		} 
		catch (HotelException e) 
		{
			System.out.println("Some exception while updation.");
		}
	}
	//**********************************************************************//
	public static void deleteHotel()
	{
		System.out.println("Enter hotel id: ");
		int hid=sc.nextInt();
		try 
		{
			int dataDeleted=htlSer.deleteHtl(hid);
			if(dataDeleted==1)
			{
				System.out.println("Hotel Data deleted");
			}
			else
			{
				System.out.println("May be some exception has occurred while deletion");
			}
		} 
		catch (HotelException e)
		{
			System.out.println(e.getMessage());
		}
	}
	//********************Room Management************************//
	private static void addRoom()
	{
		System.out.println("Enter Hotel_Id");
		String hid=sc.next();
		System.out.println("Enter Room Id");
		String rid=sc.next();
		System.out.println("Enter Room number");
		String rno=sc.next();
		System.out.println("Enter Room Type");
		String rtype=sc.next();
		System.out.println("Enter room rate per night");
		double rate=sc.nextDouble();
		System.out.println("Enter room availability");
		int rav=sc.nextInt();
		RoomDetails room=new RoomDetails(hid, rid, rno, rtype, rate, rav);
		try
		{
			int id=htlSer.addRooms(room);
			System.out.println("Room "+id+" is successfully added in the Hotel");
		}
		catch(Exception e)
		{
			System.out.println("Something went wrong adding Room in the Hotel");
		}
	}
	private static void updateRoom()
	{
		String roomupdated=null;
		System.out.println("Enter Hotel Id");
		String uhid=sc.next();
		System.out.println("Enter room Id");
		String urid=sc.next();
		System.out.println("Enter Room Number");
		String urno=sc.next();
		System.out.println("Enter Room Type");
		String urtype=sc.next();
		System.out.println("enter Room Rate Per Night");
		double urate=sc.nextDouble();
		System.out.println("Enter Room Availability");
		int urav=sc.nextInt();
		RoomDetails rooms=new RoomDetails(uhid, urid, urno, urtype, urate, urav);
		try
		{
			roomupdated=htlSer.updateRoom(rooms);
			System.out.println("Room "+roomupdated+" updated Successfully");
		}
		catch(HotelException e)
		{
			System.out.println("Some Exception updating room detials");
		}
	}
	private static void deleteRoom()
	{
		System.out.println("Enter Hotel ID ");
		String dhid=sc.next();
		System.out.println("Enter Room Id");
		String drid=sc.next();
		try
		{
			String roomdeleted=htlSer.deleteRoom(drid,dhid);
			System.out.println("Room "+roomdeleted+" deleted Successfully");
		}
		catch(Exception e)
		{
			System.out.println("Something went wrong deleting the Room "+e.getMessage());
		}
	}
	//*********************Reports*******************//
	private static void viewAllHotels() 
	{
		try
		{
			ArrayList<Hotels> hotelList=htlSer.getAllHotels();
			for(Hotels ee:hotelList)
			{
				System.out.println(ee);
			}
		}
		catch (HotelException e) 
		{
			System.out.println("Some exception occured while fetching");
			e.printStackTrace();
		}
	}
	private static void viewBookingHotel()
	{

	}
	private static void viewGuestHotel()
	{

	}
	private static void viewBookingDate()
	{
		System.out.print("Enter a date: ");
		String bDate = sc.next();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate bookingDate = LocalDate.parse(bDate, format);
		System.out.println("************Bookings OF Specified Date**************");
		try
		{
			ArrayList<BookingDetails>bookings=htlSer.viewBookingsSpecificHotel(bookingDate);
			for(BookingDetails bdetails:bookings)
			{
				System.out.println("Booking Id: "+bdetails.getId()+"\n"
						+ "Room Id: "+bdetails.getRoomId()+"\n"
						+ "User Id : " + bdetails.getUserId() + "\n"
						+ "Check In Date  : " + bdetails.getBookFrom() + "\n" 
						+ "Check Out Date : " + bdetails.getBooTo() + "\n" 
						+ "No Of Adults   : " + bdetails.getNoOfAdults() + "\n"
						+ "No Of Children : " + bdetails.getNoOfChildren() + "\n" 
						+ "Total Amount   : " + bdetails.getAmount());
			}
		}
		catch(HotelException he)
		{
			System.out.println("Some Exception occured while fetching the book details"+he.getMessage());
		}
	}
//*********************User Menu******************
	private static void userLogin()
	{
		boolean status = false;
		System.out.println("*******************Welcome to login page********************");
		System.out.println("Enter your login Id");
		String id=sc.next();
		System.out.println("Enter password");
		String password = sc.next();
		User user= new User(id,password);
		try 
		{
			status = uSer.login(user);
			if(status)
			{
				System.out.println("You have Logged in successfully!!");
			}
			else
			{
				System.out.println("Invalid Credentials. Please try again.");
			}
		} 
		catch (HotelException e)
		{
			System.out.println("Some exception while logging in"+e.getMessage());
		}
		
	}
	
	private static void userRegister()
	{
		System.out.println("***********Welcome to Registration Page****************");
		System.out.println("Enter user id");
		String uid=sc.next();
		System.out.println("Enter user name");
		String uname=sc.next();
		System.out.println("Enter password");
		String upass=sc.next();
		System.out.println("Enter email address");
		String umail=sc.next();
		System.out.println("Enter your mobile number");
		String umob=sc.next();
		System.out.println("Enter your phone number");
		String uphn=sc.next();
		System.out.println("Enter your role");
		String urole=sc.next();
		System.out.println("Enter your address");
		String uadd=sc.next();
	
		try 
		{
			User usr= new User();
		
			usr.setId(uid);
			usr.setPassword(upass);
			usr.setRole(urole);
			usr.setName(uname);
			usr.setMobileNumber(umob);
			usr.setPhoneNumber(uphn);
			usr.setAddress(uadd);
			usr.setEmail(umail);
			int dataAdded = uSer.registerUser(usr);
			if(dataAdded==1)
			{
				System.out.println("Registered Successfully");
			}
			else
			{
				System.out.println("Some error while registering.");
			}
		} 
		catch (HotelException e) 
		{
			System.out.println("May be some exception during registration");
		}
		
		
	}
	
	private static void searchHotel()
	{
		System.out.println("Enter the city where you want to book a hotel");
		String city=sc.next();
		try
		{
			ArrayList<Hotels>hList=new ArrayList<Hotels>();
			hList=uSer.searchAllHotels(city);
			System.out.println("List Of Hotels in "+city);
			for(Hotels hotel:hList)
			{
				System.out.println(hotel);
			}
		}
		catch(HotelException e)
		{
			System.out.println("Sorry!!We don't have any branch in this Location");
		}
	}
}

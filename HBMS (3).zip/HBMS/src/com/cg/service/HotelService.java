package com.cg.service;

import com.cg.bean.Hotels;
import com.cg.exception.HotelException;

public interface HotelService
{
	public int addHotels(Hotels htl) throws HotelException;
	public String updateHtl(Hotels hotels) throws HotelException;
	public String generateHotelId() throws HotelException;
	public int deleteHtl(int htlId) throws HotelException;
	public boolean validateAdmName(String cName) throws HotelException;
	public boolean validateAdmPass(String adPass) throws HotelException;
}

package com.cg.dao;

import com.cg.bean.*;
import com.cg.exception.*;


public interface HotelDao 
{
	public int addHotels(Hotels htl) throws HotelException;
	public String updateHtl(Hotels hotel) throws HotelException;
	public int deleteHtl(int htlId) throws HotelException;
	public String generateHotelId() throws HotelException;
	
}

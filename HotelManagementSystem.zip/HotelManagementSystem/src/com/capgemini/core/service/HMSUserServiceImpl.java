package com.capgemini.core.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.core.dao.HMSUserDAOImpl;
import com.capgemini.core.dao.IHMSUserDAO;
import com.capgemini.core.dto.BookingDetails;
import com.capgemini.core.dto.Hotel;
import com.capgemini.core.dto.RoomDetails;
import com.capgemini.core.dto.User;
import com.capgemini.core.exception.HMSException;

public class HMSUserServiceImpl implements IHMSUserService {
	IHMSUserDAO userDao;

	public HMSUserServiceImpl() {
		userDao = new HMSUserDAOImpl();
	}
	
	@Override
	public int register(User user) throws HMSException {
		return userDao.register(user);
	}

	@Override
	public boolean login(User user) throws HMSException {
		return userDao.login(user);
	}

	@Override
	public Hotel searchHotel(String hotelId) throws HMSException {
		return userDao.searchHotel(hotelId);
	}

	@Override
	public String bookHotel(BookingDetails bookingDetails) throws HMSException {
		return userDao.bookHotel(bookingDetails);
	}

	@Override
	public List<Hotel> search(String city) throws HMSException {
		return userDao.search(city);
	}

	@Override
	public List<RoomDetails> displayRooms(String hotelname) {
		return userDao.displayRooms(hotelname);
	}

	@Override
	public double generateBill(String roomId, LocalDate bookFrom, LocalDate bookTo) {
		return userDao.generateBill(roomId, bookFrom, bookTo);
	}

	@Override
	public boolean bookingStatus(String userId) {
		return userDao.bookingStatus(userId);
	}

}

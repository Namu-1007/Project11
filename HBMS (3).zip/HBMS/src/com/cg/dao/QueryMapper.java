package com.cg.dao;

public interface QueryMapper 
{
	String INSERT_HOTEL="INSERT INTO HOTEL VALUES(?,?,?,?,?,?,?,?,?,?,?)";
	String DELETE_HOTEL="DELETE FROM HOTEL WHERE hotel_id=?";
	String UPDATE_HOTEL="UPDATE hotel SET city=?,hotel_name=?,address=?,description=?,"
			+ "avg_rate_per_night=?,phone_no1=?,phone_no2=?,"
			+ "rating=?,email=?,fax=? WHERE hotel_id=?";
	String SEQUENCE="SELECT htl_id_seq.NEXTVAL FROM DUAL";
}

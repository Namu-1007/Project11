package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.bean.*;
import com.cg.exception.HotelException;
import com.cg.util.DBUtil;

public class UserDaoImpl implements UserDao
{
	PreparedStatement pst=null;
	Connection con=null;
	ResultSet rs=null;
	@Override
	public ArrayList<Hotels> searchAllHotels(String city) throws HotelException 
	{
		ArrayList<Hotels> hotelList= new ArrayList<Hotels>();
		Hotels hSearch = null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.SEARCH_HOTEL);
			pst.setString(1,city);
			rs=pst.executeQuery();
			while(rs.next())
			{
				hSearch=new Hotels(rs.getString("hotel_id"),
						rs.getString("city"),rs.getString("hotel_name"),
						rs.getString("address"),rs.getString("description"),
						rs.getFloat("avg_rate_per_night"),rs.getString("phone_no1"),
						rs.getString("phone_no2"),rs.getString("rating"),
						rs.getString("email"),rs.getString("fax"));
				hotelList.add(hSearch);
			}
		}
		catch (Exception e)
		{
			throw new HotelException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				con.close();
				pst.close();
			} 
			catch (SQLException e) 
			{
				throw new HotelException(e.getMessage());
			}
		}
		return hotelList;
	}

}

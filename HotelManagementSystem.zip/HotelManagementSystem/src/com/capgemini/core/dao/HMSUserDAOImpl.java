package com.capgemini.core.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.dto.BookingDetails;
import com.capgemini.core.dto.Hotel;
import com.capgemini.core.dto.RoomDetails;
import com.capgemini.core.dto.User;
import com.capgemini.core.exception.HMSException;
import com.capgemini.core.util.DBUtil;

public class HMSUserDAOImpl implements IHMSUserDAO {
	ResultSet resultSet =null;
	List<Hotel> hotelList =null;
	@Override
	public boolean login(User user) throws HMSException {
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from userDetails where user_id=? and password=?");
			preparedStatement.setString(1, user.getId());
			preparedStatement.setString(2, user.getPassword());
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				return true;
			}
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
		return false;
	}

	@Override
	public int register(User user) throws HMSException {
		//System.out.println("hello user");
		int id =0;
		ResultSet rs=null;
		try (Connection connection = DBUtil.getConnection()) {
			System.out.println(connection);
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into UserDetails VALUES(HBMSseq_UserId.nextval,?,?,?,?,?,?,?)");
			//preparedStatement.setString(1, user.getId());
			preparedStatement.setString(1, user.getPassword());
			preparedStatement.setString(2, user.getRole());
			preparedStatement.setString(3, user.getName());
			preparedStatement.setString(4, user.getMobileNumber());
			preparedStatement.setString(5, user.getPhoneNumber());
			preparedStatement.setString(6, user.getAddress());
			preparedStatement.setString(7, user.getEmail());
			
			id=preparedStatement.executeUpdate();
			if(id!=0){
				String sql1="select HBMSseq_UserId.currVal from dual";
				preparedStatement=connection.prepareStatement(sql1);
				rs=preparedStatement.executeQuery();
				while(rs.next()){
					id=rs.getInt(1);
				}
			}
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
		return id;
	}

	@Override
	public Hotel searchHotel(String hotelId) throws HMSException {
		Hotel hotel = null;
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement statement = connection.prepareStatement("select * from HotelDetails where hotel_id=?");
			statement.setString(1, hotelId);
			ResultSet resultSet = statement.executeQuery();
			resultSet.next();
			hotel = new Hotel(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3),
					resultSet.getString(4), resultSet.getString(5), resultSet.getDouble(6), resultSet.getString(7),
					resultSet.getString(8), resultSet.getString(9), resultSet.getString(10), resultSet.getString(11));
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
		return hotel;
	}

	@Override
	public String bookHotel(BookingDetails bookingDetails) throws HMSException {
		String id = null;
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement preparedStatement0=connection.prepareStatement("select booked_to,booked_from from bookingDetails where room_id=?");
			preparedStatement0.setString(1, bookingDetails.getRoomId());
			
			ResultSet resultSet1=preparedStatement0.executeQuery();
			while(resultSet1.next()){
			java.util.Date dto=resultSet1.getDate(1);
			java.util.Date dfrom=resultSet1.getDate(2);
			java.util.Date from=Date.valueOf(bookingDetails.getBookFrom());
			java.util.Date to=Date.valueOf(bookingDetails.getBooTo());
			if((dto.equals(from) || from.after(dto)) || (to.equals(dfrom)|| to.before(dfrom))){
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into BookingDetails values(?,?,?,?,?,?,?,?)");
			bookingDetails.setId(generateBookingId());
			preparedStatement.setString(1, bookingDetails.getId());
			preparedStatement.setString(2, bookingDetails.getRoomId());
			preparedStatement.setString(3, bookingDetails.getUserId());
			preparedStatement.setDate(4, Date.valueOf(bookingDetails.getBookFrom()));
			preparedStatement.setDate(5, Date.valueOf(bookingDetails.getBooTo()));
			preparedStatement.setInt(6, bookingDetails.getNoOfAdults());
			preparedStatement.setInt(7, bookingDetails.getNoOfChildren());
			preparedStatement.setDouble(8, bookingDetails.getAmount());
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next())
				id = bookingDetails.getId();}
			else{
				return "false";
			}}
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
		return id;
	}

	private String generateBookingId() throws HMSException {
		String bookId = null;
		try (Connection connection = DBUtil.getConnection()) {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("select HBMSSEQ_BOOKINGID.nextVal from dual");
			if (resultSet.next()) {
				bookId = resultSet.getInt(1) + "";
			}
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
		return bookId;
	}

	@Override
	public List<Hotel> search(String city) throws HMSException {
		 hotelList=new ArrayList<>();
		try (Connection connection = DBUtil.getConnection()) {
			System.out.println(connection);
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT hotel_name, address, discription, avg_rate_per_night, phone_no1, phone_no2, rating, email FROM hotelDetails WHERE city=?");
			preparedStatement.setString(1, city);
			resultSet=preparedStatement.executeQuery();

			while(resultSet.next())
			{
				Hotel hotel=new Hotel();
				hotel.setName(resultSet.getString("hotel_name"));
				hotel.setAddress(resultSet.getString("address"));
				hotel.setDescription(resultSet.getString("discription"));
				hotel.setAvgPerNight(resultSet.getDouble("avg_rate_per_night"));
				hotel.setPhoneNo1(resultSet.getString("phone_no1"));
				hotel.setPhoneNo2(resultSet.getString("phone_no2"));
				hotel.setRating(resultSet.getString("rating"));
				hotel.setEmail(resultSet.getString("email"));
				hotelList.add(hotel);
			}
			if (hotelList.isEmpty())
				throw new Exception("Sorry! We do not serve this location yet... ");
		connection.commit();
	}catch(Exception e){
		throw new HMSException(e.getMessage());
	}
		return hotelList;
	}

	@Override
	public List<RoomDetails> displayRooms(String hotelname) {
		List<RoomDetails> roomList=new ArrayList<>();
		try (Connection connection = DBUtil.getConnection()) {
			System.out.println(connection);
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT room_id,room_no,room_type,per_night_rate,availability FROM roomDetails r JOIN hotelDetails h ON h.hotel_id=r.hotel_id WHERE hotel_name=? and availability='AVL'");
			preparedStatement.setString(1, hotelname);
			resultSet=preparedStatement.executeQuery();

			while(resultSet.next())
			{
				RoomDetails rooms=new RoomDetails();
				rooms.setId(resultSet.getString(1));
				rooms.setNumber(resultSet.getString(2));
				rooms.setType(resultSet.getString(3));
				rooms.setPerNightRate(resultSet.getDouble(4));
				rooms.setAvailability(resultSet.getString(5));
				roomList.add(rooms);
			}
		connection.commit();
	}catch(SQLException e){
		e.printStackTrace();
		System.out.println("Something Went Wrong.");
	}
		return roomList;
	}

	@Override
	public double generateBill(String roomId, LocalDate bookFrom, LocalDate bookTo) {
		int numberOfDays = 0;
		double billAmount = 0;
		try (Connection connection = DBUtil.getConnection()) {
			System.out.println(connection);
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT per_night_rate FROM roomDetails WHERE room_id=?");
			preparedStatement.setString(1, roomId);
			resultSet=preparedStatement.executeQuery();
			RoomDetails rooms=new RoomDetails();
			while(resultSet.next())
			{
				rooms.setPerNightRate(resultSet.getDouble(1));
			}
			double amount=rooms.getPerNightRate();
			numberOfDays=bookTo.getDayOfYear()-bookFrom.getDayOfYear();
			if(numberOfDays<0){
				numberOfDays=365+numberOfDays;
			}
			billAmount=amount*numberOfDays;
		connection.commit();
	}catch(SQLException e){
		e.printStackTrace();
		System.out.println("Something Went Wrong.");
	}

		return billAmount;
	}

	@Override
	public boolean bookingStatus(String userId) {
		int flag=0;
		try (Connection connection = DBUtil.getConnection()) {
			System.out.println(connection);
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM bookingDetails WHERE user_id=?");
			preparedStatement.setString(1, userId);
			resultSet=preparedStatement.executeQuery();
			java.util.Date d=new java.util.Date();
			while(resultSet.next()){
				
				Date d1=resultSet.getDate(4);
				if(d.equals(d1) || d1.after(d))
				{
					flag=1;
				}	
			}
			if(flag>0){
				return true;
			}
		connection.commit();
	}catch(SQLException e){
		e.printStackTrace();
		System.out.println("Something Went Wrong.");
	}	
		return false;
	}
}

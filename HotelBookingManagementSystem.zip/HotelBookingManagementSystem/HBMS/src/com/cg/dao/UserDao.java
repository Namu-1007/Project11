package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.Hotels;
import com.cg.exception.HotelException;

public interface UserDao 
{
	public ArrayList<Hotels> searchAllHotels(String city) throws HotelException;
}

package com.cg.service;

import java.util.regex.Pattern;

import com.cg.bean.Hotels;
import com.cg.dao.HotelDao;
import com.cg.dao.HotelDaoImpl;
import com.cg.exception.HotelException;


public class HotelServiceImpl implements HotelService
{
	HotelDao hdao=null;
	public HotelServiceImpl()
	{
		hdao=new HotelDaoImpl();
	}
	@Override
	public int addHotels(Hotels htl) throws HotelException 
	{
		return hdao.addHotels(htl);
	}

	@Override
	public int updateHtl(int htlId) throws HotelException 
	{
		return hdao.updateHtl(htlId);
	}
	@Override
	public boolean validateAdmName(String cName) throws HotelException 
	{
		String namePattern="admin";
		if(Pattern.matches(namePattern,cName))
		{
			return true;
		}
		else
		{
			throw new HotelException("Invalid Name");
		}
	}
	@Override
	public boolean validateAdmPass(String adPass) throws HotelException
	{
		String namePattern="admin";
		if(Pattern.matches(namePattern,adPass))
		{
			return true;
		}
		else
		{
			throw new HotelException("Invalid Password");
		}
	}
	

}

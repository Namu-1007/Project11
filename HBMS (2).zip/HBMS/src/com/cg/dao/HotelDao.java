package com.cg.dao;

import com.cg.bean.*;
import com.cg.exception.*;


public interface HotelDao 
{
	public int addHotels(Hotels htl) throws HotelException;
	public int updateHtl(int htlId) throws HotelException;
	public int deleteHotels(int htlId) throws HotelException;
	
}

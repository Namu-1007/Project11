package com.cg.dao;

public interface QueryMapper 
{
//**********************Hotel Management Queries***************************//
	String INSERT_HOTEL="INSERT INTO HOTEL VALUES(?,?,?,?,?,?,?,?,?,?,?)";
	String DELETE_HOTEL="DELETE FROM HOTEL WHERE hotel_id=?";
	String UPDATE_HOTEL="UPDATE hotel SET city=?,hotel_name=?,address=?,description=?,"
			+ "avg_rate_per_night=?,phone_no1=?,phone_no2=?,"
			+ "rating=?,email=?,fax=? WHERE hotel_id=?";
	String SEQUENCE="SELECT htl_id_seq.NEXTVAL FROM DUAL";
//*************Room Management Queries****************************//
	String ADD_ROOM="INSERT INTO roomdetails VALUES(?,?,?,?,?,?)";
	String DELETE_ROOM="DELETE FROM roomdetails WHERE hotel_id=?,room-id=?";
	String UPDATE_ROOM="UPDATE roomdetaiils SET room_no=?,room_type=?,per_night_rate=?,"
			+ "availability=?";
//******************Reports Queries**********************//
	String VIEW_HOTELS="SELECT *FROM hotel";
	String VIEW_BOOKINGS_HOTEL="";
	String VIEW_GUEST_HOTEL="";
	String VIEW_BOOKING_DATE="SELECT booking_id FROM bookingdetails WHERE booked-from=?";
//******************Search Hotel Queries************************//
	String SEARCH_HOTEL="SELECT *FROM Hotel WHERE city=?";
}

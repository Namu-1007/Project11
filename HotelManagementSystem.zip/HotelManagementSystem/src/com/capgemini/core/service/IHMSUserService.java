package com.capgemini.core.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.core.dto.BookingDetails;
import com.capgemini.core.dto.Hotel;
import com.capgemini.core.dto.RoomDetails;
import com.capgemini.core.dto.User;
import com.capgemini.core.exception.HMSException;

public interface IHMSUserService {
	public boolean login(User user) throws HMSException;

	public int register(User user) throws HMSException;

	public Hotel searchHotel(String hotelId) throws HMSException;

	public String bookHotel(BookingDetails bookingDetails) throws HMSException;
	
	public List<Hotel> search(String city)throws HMSException;

	public List<RoomDetails> displayRooms(String hotelname);
	
	public double generateBill(String roomId, LocalDate bookFrom, LocalDate bookTo);
	
	public boolean bookingStatus(String userId);
} 

package com.cg.service;

import java.util.regex.Pattern;

import com.cg.bean.Hotels;
import com.cg.dao.HotelDao;
import com.cg.dao.HotelDaoImpl;
import com.cg.exception.HotelException;


public class HotelServiceImpl implements HotelService
{
	HotelDao hdao=null;
	public HotelServiceImpl()
	{
		hdao=new HotelDaoImpl();
	}
	@Override
	public int addHotels(Hotels htl) throws HotelException 
	{
		return hdao.addHotels(htl);
	}

	@Override
	public String updateHtl(Hotels hotel) throws HotelException 
	{
		return hdao.updateHtl(hotel);
	}
	@Override
	public boolean validateAdmName(String cName) throws HotelException 
	{
		String namePattern="admin";
		if(Pattern.matches(namePattern,cName))
		{
			return true;
		}
		else
		{
			throw new HotelException("Invalid Name");
		}
	}
	@Override
	public boolean validateAdmPass(String adPass) throws HotelException
	{
		String namePattern="admin";
		if(Pattern.matches(namePattern,adPass))
		{
			return true;
		}
		else
		{
			throw new HotelException("Invalid Password");
		}
	}
	@Override
	public String generateHotelId() throws HotelException 
	{
		return hdao.generateHotelId();
	}
	@Override
	public int deleteHtl(int htlId) throws HotelException
	{	
		return hdao.deleteHtl(htlId);
	}
	

}

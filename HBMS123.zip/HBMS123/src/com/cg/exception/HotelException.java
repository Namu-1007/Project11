package com.cg.exception;

public class HotelException extends Exception
{
	public HotelException(String msg)
	{
		super(msg);
	}
}

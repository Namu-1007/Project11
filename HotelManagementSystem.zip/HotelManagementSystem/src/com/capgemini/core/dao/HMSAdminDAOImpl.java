package com.capgemini.core.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.dto.BookingDetails;
import com.capgemini.core.dto.Hotel;
import com.capgemini.core.dto.RoomDetails;
import com.capgemini.core.dto.User;
import com.capgemini.core.exception.HMSException;
import com.capgemini.core.util.DBUtil;

public class HMSAdminDAOImpl implements IHMSAdminDAO {

	@Override
	public String addHotel(Hotel hotel) throws HMSException {
		String hotelId = null;
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into hotelDetails values(?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1, hotel.getId());
			preparedStatement.setString(2, hotel.getCity());
			preparedStatement.setString(3, hotel.getName());
			preparedStatement.setString(4, hotel.getAddress());
			preparedStatement.setString(5, hotel.getDescription());
			preparedStatement.setDouble(6, hotel.getAvgPerNight());
			preparedStatement.setString(7, hotel.getPhoneNo1());
			preparedStatement.setString(8, hotel.getPhoneNo2());
			preparedStatement.setString(9, hotel.getRating());
			preparedStatement.setString(10, hotel.getEmail());
			preparedStatement.setString(11, hotel.getFax());
			preparedStatement.execute();
			hotelId = hotel.getId();
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
		return hotelId;
	}

	@Override
	public String deleteHotel(String hotelId) throws HMSException {
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from hotelDetails where hotel_id=?");
			preparedStatement.setString(1, hotelId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
				PreparedStatement preparedStatement1 = connection.prepareStatement("delete from hotelDetails where hotel_id=?");
				preparedStatement1.setString(1, hotelId);
				preparedStatement1.executeQuery();
				return hotelId;
			}
			else
			{
				throw new Exception("No such Hotel Exists..!!");
			}
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}	
	}

	@Override
	public String modifyHotel(Hotel hotel) throws HMSException {
		
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from hotelDetails where hotel_id=?");
			preparedStatement.setString(1, hotel.getId());
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
				PreparedStatement preparedStatement1 = connection.prepareStatement(
						"update hotelDetails set city=?,hotel_name=?,address=?,discription=?,avg_rate_per_night=?,phone_no1=?,phone_no2=?,rating=?,email=?,fax=? WHERE hotel_id=?");
				preparedStatement1.setString(1, hotel.getCity());
				preparedStatement1.setString(2, hotel.getName());
				preparedStatement1.setString(3, hotel.getAddress());
				preparedStatement1.setString(4, hotel.getDescription());
				preparedStatement1.setDouble(5, hotel.getAvgPerNight());
				preparedStatement1.setString(6, hotel.getPhoneNo1());
				preparedStatement1.setString(7, hotel.getPhoneNo2());
				preparedStatement1.setString(8, hotel.getRating());
				preparedStatement1.setString(9, hotel.getEmail());
				preparedStatement1.setString(10, hotel.getFax());
				preparedStatement1.setString(11, hotel.getId());
				preparedStatement1.executeUpdate();
				return hotel.getId();
			}
			else
			{
				throw new Exception("No such Hotel Exists..!!");
			}
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
	}

	@Override
	public List<Hotel> listOfHotel() throws HMSException {
		ArrayList<Hotel> hotels = null;
		try (Connection connection = DBUtil.getConnection()) {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("select * from hotelDetails");
			hotels = new ArrayList<>();
			while (resultSet.next()) {
				Hotel hotel = new Hotel(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3),
						resultSet.getString(4), resultSet.getString(5), resultSet.getDouble(6), resultSet.getString(7),
						resultSet.getString(8), resultSet.getString(9), resultSet.getString(10),
						resultSet.getString(11));
				hotels.add(hotel);
			}
			if (hotels.isEmpty())
				throw new Exception("No hotels to display");
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
		return hotels;
	}

	@Override
	public List<BookingDetails> specificHotelBookings(String hotelId) throws HMSException {
		ArrayList<BookingDetails> bookings = null;
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement(
					"select booking_id from bookingdetails b join roomdetails r on b.room_id=r.room_id where hotel_id=?");
			preparedStatement.setString(1, hotelId);
			ResultSet resultSet = preparedStatement.executeQuery();
			bookings = new ArrayList<>();
			while (resultSet.next()) {
				PreparedStatement preparedStatement2 = connection
						.prepareStatement("select * from bookingdetails where booking_id=?");
				preparedStatement2.setString(1, resultSet.getString("booking_id"));
				ResultSet resultSet2 = preparedStatement2.executeQuery();
				while (resultSet2.next()) {
					BookingDetails bookingDetails = new BookingDetails(resultSet2.getString(1), resultSet2.getString(2),
							resultSet2.getString(3), resultSet2.getDate(4).toLocalDate(),
							resultSet2.getDate(5).toLocalDate(), resultSet2.getInt(6), resultSet2.getInt(7),
							resultSet2.getDouble(8));
					bookings.add(bookingDetails);
				}
			}

			if (bookings.isEmpty())
				throw new Exception("No bookings has been made in Hotel: " + hotelId);
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
		return bookings;
	}

	@Override
	public List<User> guestOfSpecificHotel(String hotelId) throws HMSException {
		ArrayList<User> users = null;
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select distinct u.user_id from userDetails u,hotelDetails h,"
							+ "bookingdetails b,roomdetails r where b.room_id=r.room_id and "
							+ "u.user_id=b.user_id and r.hotel_id=h.hotel_id and h.hotel_id=?");
			preparedStatement.setString(1, hotelId);
			ResultSet resultSet = preparedStatement.executeQuery();
			users = new ArrayList<>();
			while (resultSet.next()) {
				PreparedStatement preparedStatement2 = connection
						.prepareStatement("select * from userDetails where user_id=?");
				preparedStatement2.setString(1, resultSet.getString(1));
				ResultSet resultSet2 = preparedStatement2.executeQuery();
				while (resultSet2.next()) {
					User user = new User(resultSet2.getString("user_id"), resultSet2.getString("password"), resultSet2.getString("role"),
							resultSet2.getString("user_name"), resultSet2.getString("mobile_no"), resultSet2.getString("phone_no"),
							resultSet2.getString("address"), resultSet2.getString("email"));
					users.add(user);
				}
			}

			if (users.isEmpty())
				throw new Exception("No guestes booked in hotel: " + hotelId);
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
		return users;
	}

	@Override
	public List<BookingDetails> bookingOfSpecificDate(LocalDate date) throws HMSException {
		ArrayList<BookingDetails> bookings = null;
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from bookingdetails where booked_from=?");
			preparedStatement.setDate(1, Date.valueOf(date));
			ResultSet resultSet = preparedStatement.executeQuery();
			bookings = new ArrayList<>();
			while (resultSet.next()) {
				BookingDetails bookingDetails = new BookingDetails(resultSet.getString(1), resultSet.getString(2),
						resultSet.getString(3), resultSet.getDate(4).toLocalDate(), resultSet.getDate(5).toLocalDate(),
						resultSet.getInt(6), resultSet.getInt(7), resultSet.getDouble(8));
				bookings.add(bookingDetails);
			}
			if (bookings.isEmpty())
				throw new Exception("No bookings has been made on : " + date);
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
		return bookings;
	}

	@Override
	public String addRoom(RoomDetails room) throws HMSException {
		String id = null;
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement(
					"insert into roomdetails(hotel_id,room_id,room_no,room_type,per_night_rate,availability) values(?,?,?,?,?,?)");
			preparedStatement.setString(1, room.getHotelId());
			preparedStatement.setString(2, room.getId());
			preparedStatement.setString(3, room.getNumber());
			preparedStatement.setString(4, room.getType());
			preparedStatement.setDouble(5, room.getPerNightRate());
			preparedStatement.setString(6, room.getAvailability());
			preparedStatement.execute();
			id = room.getId();
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
		return id;
	}

	@Override
	public String deleteRoom(String roomID,String hotelID) throws HMSException {
		String id = null;
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from roomDetails where hotel_id=? and room_id=?");
			preparedStatement.setString(1, hotelID);
			preparedStatement.setString(2, roomID);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
				PreparedStatement preparedStatement1 = connection
						.prepareStatement("delete from roomdetails where room_id=? and hotel_id=?");
				preparedStatement1.setString(1, roomID);
				preparedStatement1.setString(2, hotelID);
				preparedStatement1.executeQuery();
				return roomID;
			}
			else
			{
				throw new Exception("HotelID OR RoomID Does Not Exists..!!");
			}
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
	}

	@Override
	public String modifyRoom(RoomDetails room) throws HMSException {
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from roomDetails where room_id=?");
			preparedStatement.setString(1, room.getId());
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
				PreparedStatement preparedStatement1 = connection.prepareStatement(
						"update roomdetails SET room_no=?,room_type=?,per_night_rate=?,availability=? WHERE room_id=?");
				preparedStatement1.setString(1, room.getNumber());
				preparedStatement1.setString(2, room.getType());
				preparedStatement1.setDouble(3, room.getPerNightRate());
				preparedStatement1.setString(4, room.getAvailability());
				preparedStatement1.setString(5, room.getId());
				System.out.println("Helloooo");
				preparedStatement1.executeUpdate();
				System.out.println("welcomessss");
				return room.getId();
			}
			else
			{
				throw new Exception("RoomID Does Not Exists..!!");
			}
			
		} catch (Exception e) {
			throw new HMSException(e.getMessage());
		}
	}
}

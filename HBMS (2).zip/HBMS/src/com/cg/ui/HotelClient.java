package com.cg.ui;

import java.util.Scanner;

import com.cg.service.HotelService;
import com.cg.service.HotelServiceImpl;


public class HotelClient 
{
	static Scanner sc=null;
	static HotelService htlSer=null;

	public static void main(String[] args) 
	{
		htlSer=new HotelServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("Login As \n1.Admin\n2.Hotel Employee\n3.User");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1: System.out.println("************Welcome Admin !!*************");
			System.out.println("Enter your login credentials");
			System.out.println("Enter your name");
			String name=sc.next();
			System.out.println("Enter your password");
			String pass=sc.next();
			if(htlSer.validateAdmName(cName))
			{
				if(htlSer.validateAdmName(pass))
				{
					
				}
			}
			
			break;
			}
		}
	}

}

package com.cg.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.bean.*;
import com.cg.exception.*;


public interface HotelDao 
{
//******************Hotel Management*****************//
	public int addHotels(Hotels htl) throws HotelException;
	public String updateHtl(Hotels hotel) throws HotelException;
	public int deleteHtl(int htlId) throws HotelException;
	public String generateHotelId() throws HotelException;
//***************Room Management******************//
	public int addRooms(RoomDetails room) throws HotelException;
	public String updateRoom(RoomDetails room) throws HotelException;
	public String deleteRoom(String roomid, String hid) throws HotelException;
//*******************View Reports******************************//
	public ArrayList<Hotels> getAllHotels()throws HotelException;
	public ArrayList<BookingDetails> viewBookingsSpecificHotel(LocalDate bookdate) throws HotelException;
}

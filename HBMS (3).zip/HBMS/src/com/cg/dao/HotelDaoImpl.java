package com.cg.dao;

import java.sql.*;

import com.cg.bean.*;
import com.cg.exception.*;
import com.cg.util.DBUtil;
import com.cg.dao.*;


public class HotelDaoImpl implements HotelDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public int addHotels(Hotels htl) throws HotelException
	{
		int dataAdded=0;	
		try
		{
			con =DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.INSERT_HOTEL);

			pst.setString(1,generateHotelId());
			pst.setString(2,htl.getCity());
			pst.setString(3,htl.getHotelName());
			pst.setString(4,htl.getAddress());
			pst.setString(5,htl.getDescription());
			pst.setFloat(6,htl.getAvgRate());
			pst.setString(7,htl.getPh1());
			pst.setString(8,htl.getPh2());
			pst.setString(9,htl.getRating());
			pst.setString(10,htl.getEmail());
			pst.setString(11,htl.getFax());

			dataAdded=pst.executeUpdate();
		}
		catch(Exception e)
		{		
			throw new HotelException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
				st.close();
			}
			catch(SQLException e)
			{
				throw new HotelException(e.getMessage());
			}
		}
		return dataAdded;	
	}

	@Override
	public String updateHtl(Hotels hotel) throws HotelException 
	{
		String dataUpdated=null;
		try
		{
			con=DBUtil.getCon();
			PreparedStatement pst1 = con.prepareStatement("SELECT * from hotel where hotel_id=?");
			pst1.setString(1, hotel.getHotelId());
			rs=pst1.executeQuery();
			if(rs.next())
			{
				pst=con.prepareStatement(QueryMapper.UPDATE_HOTEL);
				pst.setString(1, hotel.getCity());
				pst.setString(2, hotel.getHotelName());
				pst.setString(3, hotel.getAddress());
				pst.setString(4, hotel.getDescription());
				pst.setFloat(5, hotel.getAvgRate());
				pst.setString(6, hotel.getPh1());
				pst.setString(7, hotel.getPh2());
				pst.setString(8, hotel.getRating());
				pst.setString(9, hotel.getEmail());
				pst.setString(10, hotel.getFax());
				pst.setString(11, hotel.getHotelId());
				return hotel.getHotelId();
			
			}
			else
			{
				throw new Exception("No such Hotel Exists..!!");
			}
		}
		catch(Exception e)
		{		
			throw new HotelException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new HotelException(e.getMessage());
			}
		}
	}

	@Override
	public String generateHotelId() throws HotelException 
	{
		String htlid=null;
		
		try
		{
			con =DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(QueryMapper.SEQUENCE);
			rs.next();
			htlid=rs.getString(1);
		}
		catch(Exception e)
		{
			throw new HotelException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new HotelException(e.getMessage());
			}	
		}
		return htlid;		
		}

	@Override
	public int deleteHtl(int htlId) throws HotelException 
	{
		int dataDeleted;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.DELETE_HOTEL);
			pst.setInt(1, htlId);
			dataDeleted=pst.executeUpdate();
		}
		catch(Exception e)
		{
			throw new HotelException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new HotelException(e.getMessage());
			}
		}
		return dataDeleted;
	}
}
package com.capgemini.core.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.core.dao.HMSAdminDAOImpl;
import com.capgemini.core.dao.IHMSAdminDAO;
import com.capgemini.core.dto.BookingDetails;
import com.capgemini.core.dto.Hotel;
import com.capgemini.core.dto.RoomDetails;
import com.capgemini.core.dto.User;
import com.capgemini.core.exception.HMSException;

public class HMSAdminServiceImpl implements IHMSAdminService {
	IHMSAdminDAO adminDao;

	public HMSAdminServiceImpl() {
		adminDao = new HMSAdminDAOImpl();
	}

	@Override
	public String addHotel(Hotel hotel) throws HMSException {
		return adminDao.addHotel(hotel);
	}

	@Override
	public String deleteHotel(String hotelId) throws HMSException {
		return adminDao.deleteHotel(hotelId);
	}

	@Override
	public String modifyHotel(Hotel hotel) throws HMSException {
		return adminDao.modifyHotel(hotel);
	}

	@Override
	public List<Hotel> listOfHotel() throws HMSException {
		return adminDao.listOfHotel();
	}

	@Override
	public List<BookingDetails> specificHotelBookings(String hotelId) throws HMSException {
		return adminDao.specificHotelBookings(hotelId);
	}

	@Override
	public List<User> guestOfSpecificHotel(String hotelId) throws HMSException {
		return adminDao.guestOfSpecificHotel(hotelId);
	}

	@Override
	public List<BookingDetails> bookingOfSpecificDate(LocalDate date) throws HMSException {
		return adminDao.bookingOfSpecificDate(date);
	}

	@Override
	public String addRoom(RoomDetails room) throws HMSException {
		return adminDao.addRoom(room);
	}

	@Override
	public String deleteRoom(String roomID,String hotelID) throws HMSException {
		return adminDao.deleteRoom(roomID,hotelID);
	}

	@Override
	public String modifyRoom(RoomDetails room) throws HMSException {
		return adminDao.modifyRoom(room);
	}

}

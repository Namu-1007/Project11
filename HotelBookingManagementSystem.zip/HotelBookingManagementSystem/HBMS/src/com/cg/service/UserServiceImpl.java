package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Hotels;
import com.cg.dao.UserDao;
import com.cg.dao.UserDaoImpl;
import com.cg.exception.HotelException;

public class UserServiceImpl implements UserService
{
	UserDao userdao=null;
	public UserServiceImpl()
	{
		userdao=new UserDaoImpl();
	}

	@Override
	public ArrayList<Hotels> searchAllHotels(String city) throws HotelException 
	{
		return userdao.searchAllHotels(city);
	}

}

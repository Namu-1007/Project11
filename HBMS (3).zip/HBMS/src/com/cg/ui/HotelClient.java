package com.cg.ui;

import java.util.Scanner;

import com.cg.bean.Hotels;
import com.cg.exception.HotelException;
import com.cg.service.HotelService;
import com.cg.service.HotelServiceImpl;


public class HotelClient 
{
	static Scanner sc=null;
	static HotelService htlSer=null;

	public static void main(String[] args) 
	{
		htlSer=new HotelServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("Login As\n1.Admin\n2.Hotel Employee\n3.User");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1: System.out.println("************Welcome Admin !!*************");
			System.out.println("Enter your login credentials");
			System.out.println("Enter your name");
			String name=sc.next();
			System.out.println("Enter your password");
			String pass=sc.next();
				try 
				{
					if(htlSer.validateAdmName(name))
					{
						if(htlSer.validateAdmPass(pass))
						{
							System.out.println("You have logged in successfully.Select your preferrred operation");
							System.out.println("1.Hotel Management\n"
									+ "2.Room Management\n3.View Reports");
							int c=sc.nextInt();
							switch(c)
							{
							case 1:System.out.println("1.Add Hotel\n2.Update Hotel\n3.Delete Hotel");
								System.out.println("Select your Choice ");
								int hmchoice=sc.nextInt();
								switch(hmchoice)
								{
								case 1:addHotel();
								break;
								case 2:updateHotel();
								break;
								case 3:deleteHotel();
								break;
								default: System.exit(0);
								}
							break;
							case 2:System.out.println("1.Add Rooms\n2.Update Rooms\3.Delete Rooms");
								break;
							case 3:System.out.println("1.View List Of Hotels\n2.View Bookings Of Specific hotel"
									+ "\n3.View Guest List of Specific Hotel"
									+ "View Bookings for Specified Date");
								break;
							default:
								System.exit(0);
							}
							
							
						}
					}
				} 
				catch (HotelException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
//**************************Main Ends Here***************************//
	public static void addHotel()
	{
		System.out.println("Enter Hotel City");
		String city=sc.next();
		System.out.println("Enter Hotel Name");
		String hname=sc.next();
		System.out.println("Enter Hotel Address");
		String add=sc.next();
		System.out.println("Enter Hotel Description");
		String des=sc.next();
		System.out.println("Enter Average Rate Per Night");
		float rate=sc.nextFloat();
		System.out.println("Enter first Phone Number");
		String fphn=sc.next();
		System.out.println("Enter second Phone Number");
		String sphn=sc.next();
		System.out.println("Enter Hotel Rating");
		String rating=sc.next();
		System.out.println("Enter EmailId");
		String em=sc.next();
		System.out.println("Enter Fax Number");
		String fax=sc.next();
		
		try
		{
			Hotels htls=new Hotels(htlSer.generateHotelId(),
				city,hname,add,des,rate,fphn,sphn,rating,em,fax);
			int inserted=htlSer.addHotels(htls);
			if(inserted==1)
			{
				System.out.println("Hotel details are successfully inserted");
			}
			else
			{
				System.out.println("May be Some Exception");
			}
		} 
		catch (HotelException e) 
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
	}
	//*********************************************************************//
	public static void updateHotel()
	{
		System.out.println("Enter hotel id: ");
		String hid=sc.next();
		System.out.println("Enter Hotel City");
		String city=sc.next();
		System.out.println("Enter Hotel Name");
		String hname=sc.next();
		System.out.println("Enter Hotel Address");
		String add=sc.next();
		System.out.println("Enter Hotel Description");
		String des=sc.next();
		System.out.println("Enter Average Rate Per Night");
		float rate=sc.nextFloat();
		System.out.println("Enter first Phone Number");
		String phn1=sc.next();
		System.out.println("Enter second Phone Number");
		String phn2=sc.next();
		System.out.println("Enter Hotel Rating");
		String rating=sc.next();
		System.out.println("Enter EmailId");
		String em=sc.next();
		System.out.println("Enter Fax Number");
		String fax=sc.next();
		
		Hotels hotels=new Hotels(hid,city,hname,add,des,rate,phn1,phn2,rating,em,fax);
		try 
		{
			String upd=htlSer.updateHtl(hotels);
			
			System.out.println("Hotel " +upd+" updated successfully!");
		} 
		catch (HotelException e) 
		{
			System.out.println("Some exception while updation.");
		}
	}
	//**********************************************************************//
	public static void deleteHotel()
	{
		System.out.println("Enter hotel id: ");
		int hid=sc.nextInt();
		try 
		{
			int dataDeleted=htlSer.deleteHtl(hid);
			if(dataDeleted==1)
			{
				System.out.println("Hotel Data deleted");
			}
			else
			{
				System.out.println("May be some exception has occurred while deletion");
			}
		} 
		catch (HotelException e)
		{
			System.out.println(e.getMessage());
		}
	}
}

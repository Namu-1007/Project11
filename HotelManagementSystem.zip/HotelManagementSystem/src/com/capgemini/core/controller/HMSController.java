package com.capgemini.core.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.core.dto.User;
import com.capgemini.core.exception.HMSException;
import com.capgemini.core.service.HMSAdminServiceImpl;
import com.capgemini.core.service.HMSUserServiceImpl;
import com.capgemini.core.service.IHMSAdminService;
import com.capgemini.core.service.IHMSUserService;

@WebServlet("/HMSControllerMap")
public class HMSController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IHMSAdminService adminService;
	private IHMSUserService userService;

	public HMSController() {
		adminService = new HMSAdminServiceImpl();
		userService = new HMSUserServiceImpl();
	}

	public void init(ServletConfig config) throws ServletException {
	}

	public void destroy() {
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		RequestDispatcher dispatcher = null;
		if (action != null) {
			if (action.equalsIgnoreCase("ValidateUser")) {

				try {
					String userId = request.getParameter("user_id");
					String password = request.getParameter("password");
					User user = new User(userId, password);
					userService.login(user);
				} catch (HMSException e) {

				}
				String error = "Please check user and passowrd";
				request.setAttribute("MsgObj", error);
				dispatcher = request.getRequestDispatcher("index.jsp");
				dispatcher.forward(request, response);
			}
		} else {

		}

	}

}

package com.cg.core;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.core.dto.User;
import com.capgemini.core.exception.HMSException;
import com.capgemini.core.service.HMSUserServiceImpl;
import com.capgemini.core.service.IHMSUserService;

@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IHMSUserService userService = new HMSUserServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	protected void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userId = request.getParameter("user_id");
		String password = request.getParameter("password");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<body>");

		boolean status = false;
		User user = new User(userId, password);
		try {
			status = userService.login(user);
			if (status)
				out.println("<p>Logged in successfully</p>");
		} catch (HMSException e) {
			out.println("<p>Something went wrong. Reason " + e.getMessage() + "</p>");
		}
		out.println("</html>");
		out.println("</body>");
	}
}
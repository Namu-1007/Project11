package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Hotels;
import com.cg.exception.HotelException;

public interface UserService 
{
	public ArrayList<Hotels> searchAllHotels(String city) throws HotelException;
}

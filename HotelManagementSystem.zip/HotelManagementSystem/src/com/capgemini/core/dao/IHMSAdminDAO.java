package com.capgemini.core.dao;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.core.dto.BookingDetails;
import com.capgemini.core.dto.Hotel;
import com.capgemini.core.dto.RoomDetails;
import com.capgemini.core.dto.User;
import com.capgemini.core.exception.HMSException;

public interface IHMSAdminDAO {

	public String addHotel(Hotel hotel) throws HMSException;

	public String deleteHotel(String hotelId) throws HMSException;

	public String modifyHotel(Hotel hotel) throws HMSException;

	public List<Hotel> listOfHotel() throws HMSException;

	public List<BookingDetails> specificHotelBookings(String hotelId) throws HMSException;

	public List<User> guestOfSpecificHotel(String hotelId) throws HMSException;

	public List<BookingDetails> bookingOfSpecificDate(LocalDate date) throws HMSException;

	public String addRoom(RoomDetails room) throws HMSException;

	public String deleteRoom(String roomID,String hotelID) throws HMSException;

	public String modifyRoom(RoomDetails room) throws HMSException;

}

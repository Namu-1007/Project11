package com.capgemini.core.dto;

public class Hotel {
	private String id;
	private String city;
	private String name;
	private String address;
	private String description;
	private double avgPerNight;
	private String phoneNo1;
	private String phoneNo2;
	private String rating;
	private String email;
	private String fax;

	public Hotel() {
		super();
	}

	public Hotel(String id, String city, String name, String address, String description, double avgPerNight,
			String phoneNo1, String phoneNo2, String rating, String email, String fax) {
		super();
		this.id = id;
		this.city = city;
		this.name = name;
		this.address = address;
		this.description = description;
		this.avgPerNight = avgPerNight;
		this.phoneNo1 = phoneNo1;
		this.phoneNo2 = phoneNo2;
		this.rating = rating;
		this.email = email;
		this.fax = fax;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getAvgPerNight() {
		return avgPerNight;
	}

	public void setAvgPerNight(double avgPerNight) {
		this.avgPerNight = avgPerNight;
	}

	public String getPhoneNo1() {
		return phoneNo1;
	}

	public void setPhoneNo1(String phoneNo1) {
		this.phoneNo1 = phoneNo1;
	}

	public String getPhoneNo2() {
		return phoneNo2;
	}

	public void setPhoneNo2(String phoneNo2) {
		this.phoneNo2 = phoneNo2;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	@Override
	public String toString() {
		return "Hotel [ name=" + name + ", address=" + address + ", description=" + description
				+ ", avgPerNight=" + avgPerNight + ", phoneNo1=" + phoneNo1 + ", phoneNo2=" + phoneNo2 + ", rating="
				+ rating + ", email=" + email + "]";
	}
	
}
